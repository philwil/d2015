/* Our second set comes from the i386 files.  */
#include "linux/ioctlent.h"
