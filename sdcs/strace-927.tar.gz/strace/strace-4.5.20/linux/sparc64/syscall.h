#include "../sparc/syscall.h"
