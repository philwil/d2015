
#include "compile.h"
#include "version.h"

char global_stamp[] = "$Package: " TOOLCHAIN_NAME " release " TOOLCHAIN_RELEASE ", build " TOOLCHAIN_VERSION " $";
